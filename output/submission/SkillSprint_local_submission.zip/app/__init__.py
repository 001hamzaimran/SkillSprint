"""SkillSprint application."""
